package funqy;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class FunqyIT extends FunqyTest {

    // Run the same tests

}
