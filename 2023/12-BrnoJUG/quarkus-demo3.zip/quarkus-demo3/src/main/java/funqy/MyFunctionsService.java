package funqy;

import jakarta.enterprise.context.ApplicationScoped;

@ApplicationScoped
public class MyFunctionsService {

    public String decorate(String string) {
        return "\n############### DECORATOR ############### \n"
                + string
                + "\n############### DECORATOR ###############\n";
    }

}
