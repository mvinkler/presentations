package funqy;

import io.quarkus.funqy.Funq;
import io.quarkus.funqy.knative.events.CloudEvent;
import io.quarkus.funqy.knative.events.CloudEventBuilder;
import io.quarkus.funqy.knative.events.CloudEventMapping;
import jakarta.inject.Inject;
import org.jboss.logging.Logger;

public class SimpleFunctionChain {

    private static final Logger log = Logger.getLogger(SimpleFunctionChain.class);
    @Inject
    MyFunctionsService injectedService;

    /**
     * Expects knative event of type "defaultChain".  Creates event of type "defaultChain.output".
     *
     * This function is triggered by an external curl invocation.
     */
    @Funq
    public String defaultChain(String input) {
        log.info(input + "::defaultChain");
        return input + "::defaultChain";
    }

    /**
     * This is triggered by defaultChain and is example of using application.properties to
     * map the cloud event to this function and to map response.  Response will trigger
     * the annotatedChain function.
     *
     * application.properties will have:
     * quarkus.funqy.knative-events.mapping.configChain.trigger=defaultChain.output
     * quarkus.funqy.knative-events.mapping.configChain.response-type=annotated
     * quarkus.funqy.knative-events.mapping.configChain.response-source=configChain
     */
    @Funq
    public String configChain(String input) {
        log.info(input + "::configChain");
        return input + "::configChain";
    }

    /**
     * Triggered by configChain output.
     *
     * Example of mapping the cloud event via an annotation.
     */
    @Funq
    @CloudEventMapping(trigger = "annotated", responseSource = "annotated", responseType = "builderChain")
    public String annotatedChain(String input) {
        log.info(input + "::annotatedChain");
        return input + "::annotatedChain";
    }

    /**
     * Triggered by annotatedChain output.
     *
     * Example of CloudEventBuilder.
     * @param input
     */
    @Funq
    public CloudEvent<String> builderChain(CloudEvent<String> input) {
        log.info(input.data() + "::builderChain");
        return CloudEventBuilder.create()
                .id("myCustomId")
                .source("myCustomBuilderChainSource")
                .type("lastChainLink")
                .subject("myCustomSubject")
                .build(input.data() + "::builderChain");
    }

    /**
     * Last event in chain. Has no output. Triggered by builderChain.
     */
    @Funq
    public void lastChainLink(CloudEvent<String> input) {
        log.info(injectedService.decorate(input.data() + "::lastChainLink" +
                "\n ID:" + input.id() +
                "\n SOURCE:" + input.source() +
                "\n SUBJECT:" + input.subject() +
                "\n TYPE:" + input.type()));
    }
}
